import React from 'react'
import "./Contact.css"
import Map from "./Map"
import Sidebar from '../Sidebar/Sidebar'
import HomeHeader from  "../HomeHeader/HomeHeader";
export default function Contact() {
  return (
    <div>
     <HomeHeader />
    <Sidebar/>
    <Map/>
    <section id="contact" className="py-5 mt-4 d-flex">
      <div className="col-lg-3 col-md-6 mb-5">
        <h3 className="text-white mb-4 pl-3">Get In Touch</h3>
        <p className="pl-3">Siddhesh Optimus, Shop No. 2, opposite LUNKAD QUEENSLAND</p>
        <p><i className="fa fa-map-marker-alt mr-2"></i> Pune, Maharashtra 411014</p>
        <p><i className="fa fa-phone-alt mr-2"></i>+012 345 67890</p>
        <p><i className="fa fa-envelope mr-2"></i>info@example.com</p>
      </div>
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-8">
            <form >
              <div className="form-group">
                <input type="text" className="form-control" placeholder="Your Name" required />
              </div>
              <div className="form-group">
                <input type="email" className="form-control" placeholder="Your Email" required />
              </div>
              <div className="form-group">
                <textarea className="form-control" rows="5" placeholder="Your Message" required></textarea>
              </div>
              <button type="submit" className="btn btn-primary btn-block">Submit</button>
            </form>
          </div>
        </div>
      </div>
    </section>
    
  </div>
  )
}
