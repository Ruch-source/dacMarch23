import React from 'react'

export default function Price() {
  return (
    <div>
      <h1>Our Price Plan</h1>
    </div>
  )
}
