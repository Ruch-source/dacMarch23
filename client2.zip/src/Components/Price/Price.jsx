import React from 'react'
import Sidebar from '../Sidebar/Sidebar'
import HomeHeader from '../HomeHeader/HomeHeader'
export default function Price() {
  return (
    <div>
      <HomeHeader/>
      <Sidebar/>
      <section class="about-section">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <h2>Our Pricing Plan</h2>
                
              </div>
            </div>
          </div>
      </section>
      <div className="row">
      <div className="col-md-4">
        <div className="service-card">
          <div className="d-inline-flex flex-column align-items-center justify-content-center bg-info rounded-circle shadow mt-2 mb-4" style={{ width: '200px', height: '200px', border: '15px solid #ffffff' }}>
            <h3 className="text-white">Basic</h3>
            <h1 className="display-4 text-white mb-0">
              <small className="align-top" style={{ fontSize: '22px', lineHeight: '45px' }}>Rs</small>149<small className="align-bottom" style={{ fontSize: '16px', lineHeight: '40px' }}>/ Mo</small>
            </h1>
          </div>
          <ul>
            <div className="provided">
              <li>Dry Cleaning</li>
              <li>Laundry Services</li>
              <li>Leather Cleaning</li>
            </div>
            <div className="non">
              <li>Carpet Cleaning</li>
              <li>Ironing & Folding</li>
              <li>Pickup & Delivery</li>
            </div>
          </ul>
          <button>Add Plan</button>
        </div>
      </div>

      <div className="col-md-4">
        <div className="service-card">
          <div className="d-inline-flex flex-column align-items-center justify-content-center bg-info rounded-circle shadow mt-2 mb-4" style={{ width: '200px', height: '200px', border: '15px solid #ffffff' }}>
            <h3 className="text-white">Standard</h3>
            <h1 className="display-4 text-white mb-0">
              <small className="align-top" style={{ fontSize: '22px', lineHeight: '45px' }}>Rs</small>249<small className="align-bottom" style={{ fontSize: '16px', lineHeight: '40px' }}>/ Mo</small>
            </h1>
          </div>
          <ul>
            <div className="provided">
              <li>Dry Cleaning</li>
              <li>Laundry Services</li>
              <li>Leather Cleaning</li>
              <li>Carpet Cleaning</li>
            </div>
            <div className="non">
              <li>Ironing & Folding</li>
              <li>Pickup & Delivery</li>
            </div>
          </ul>
          <button className="mt-2">Add Plan</button>
        </div>
      </div>

      <div className="col-md-4">
        <div className="service-card">
          <div className="d-inline-flex flex-column align-items-center justify-content-center bg-info rounded-circle shadow mt-2 mb-4" style={{ width: '200px', height: '200px', border: '15px solid #ffffff' }}>
            <h3 className="text-white">Premium</h3>
            <h1 className="display-4 text-white mb-0">
              <small className="align-top" style={{ fontSize: '22px', lineHeight: '45px' }}>Rs</small>500<small className="align-bottom" style={{ fontSize: '16px', lineHeight: '40px' }}>/ Mo</small>
            </h1>
          </div>
          <ul>
            <div className="provided">
              <li>Dry Cleaning</li>
              <li>Laundry Services</li>
              <li>Leather Cleaning</li>
              <li>Carpet Cleaning</li>
              <li>Ironing & Folding</li>
              <li>Pickup & Delivery</li>
            </div>
          </ul>
          <button className="mt-2">Add Plan</button>
        </div>
      </div>
    </div>
    </div>
  )
}
