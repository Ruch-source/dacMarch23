import React from 'react'
import "./Contact.css";
export default function Map() {
  return (
    <div>
      <div class="col-sm-12 col-md-8 mx-auto">
          <div class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7564.209114706531!2d73.90240743756291!3d18.569324329263324!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2c137f664fd53%3A0xe603796f0f8ed247!2sThe%20Laundry%20Hub!5e0!3m2!1sen!2sin!4v1686464800794!5m2!1sen!2sin" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
          </div>
        </div>
    </div>
  )
}
