import React from "react";
import HomeHeader from "../HomeHeader/HomeHeader";
import "./About.css";
import Sidebar from "../Sidebar/Sidebar";
import about1 from "../../Assets/about.jpg";
import about2 from "../../Assets/about-1.jpg";
import about3 from "../../Assets/about-2.jpeg";
import Footer2 from "../Footer2/Footer2";
export default function About() {
  return (
    <>
      <HomeHeader />
      <Sidebar />

      <div
        className="home-container"
        style={{ height: "85vh", marginLeft: "4vw" }}
      >
        <section className="about-section">
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <h2>About Us</h2>
                <p>
                  We are a professional laundry shop dedicated to providing
                  high-quality laundry services to our customers. With years of
                  experience, we understand the importance of clean and fresh
                  laundry in your daily life.
                </p>
                <p>
                  Our team of skilled professionals ensures that your clothes
                  are treated with utmost care and attention. We use the latest
                  technology and eco-friendly products to deliver outstanding
                  results. Your satisfaction is our top priority.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="tagline-section h-60 ">
          <h3>Why Choose Us?</h3>
          <div className="container">
            <div className="row mt-5">
              <div className="col col-md-4 mb-5">
                <img src={about2} alt="My Image" className="h-100" />
              </div>
              <div className="col-md-4 mb-5 ">
                <h3 className="tagline">Professional Staff</h3>
                <p>
                  Our highly trained and professional staff pays attention to
                  every detail, ensuring that your clothes are handled with care
                  and precision.
                </p>
              </div>
              <div className="col-md-4 mb-5">
                <img src={about3} alt="My Image" className="h-100" />
              </div>
              <div className="col col-md-4 h-25 mt-5">
                <h3 className="tagline">Eco-Friendly Solutions</h3>
                <p>
                  We use environmentally friendly products and methods to
                  minimize our impact on the environment. Your clothes are in
                  safe hands.
                </p>
              </div>
              <div className="col-md-4 mb-0">
                <img src={about1} alt="My Image" className="h-50 w-100 mt-5" />
              </div>
              <div className="col-md-4 h-25 mt-5">
                <h3 className="tagline">Fast and Efficient</h3>
                <p>
                  Our dedicated team ensures quick turnaround time without
                  compromising on quality. We understand the value of your time.
                </p>
              </div>
            </div>
          </div>
        </section>
        <Footer2 />
      </div>
    </>
  );
}
