import React from 'react'
import "./Service.css";
import offer1 from '../../Assets/order.png';
import offer2 from '../../Assets/pickup.png';
import offer3 from '../../Assets/prepare.png';
import offer4 from '../../Assets/delivery.png';

export default function Offer() {
  return (
    <div>
        <h2 class="text-center mt-5 ">How We Work</h2>
      <div class="container">
      
      <div class="row justify-content-center">
        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="process-step">
            <img src={offer1} alt="Order Placement" />
            <h4>1. Order Place</h4>
            <p>Conveniently place your order online or through our app.</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="process-step">
            <img src={offer2} alt="Free Pickup" />
            <h4>2. Pickup Available</h4>
            <p>Schedule your pickup at your preferred location and time.</p>
            
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="process-step">
            <img src={offer3} alt="Prepare Order" />
            <h4>3. Prepare Order</h4>
            <p>Our professional team will carefully clean and prepare items.</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="process-step">
            <img src={offer4} alt="Free Delivery" />
            <h4>4. Free Delivery</h4>
            <p>
              We'll deliver your freshly cleaned items right to your doorstep.
            </p>
          </div>
        </div>
      </div>
    </div>
    </div>
  )
}
