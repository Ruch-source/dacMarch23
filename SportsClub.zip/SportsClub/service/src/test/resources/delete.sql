--This script will not be overridden.
--Author: Jan Tomasek
delete from playerInfo;
delete from player;
delete from team;
delete from manager;