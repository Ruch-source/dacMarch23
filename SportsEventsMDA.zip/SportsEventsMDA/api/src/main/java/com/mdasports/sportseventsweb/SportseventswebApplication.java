package com.mdasports.sportseventsweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*Sprint 2 28/05/2020*/
@SpringBootApplication
public class SportseventswebApplication {
    public static void main(String[] args) {
        SpringApplication.run(SportseventswebApplication.class, args);
    }
}
