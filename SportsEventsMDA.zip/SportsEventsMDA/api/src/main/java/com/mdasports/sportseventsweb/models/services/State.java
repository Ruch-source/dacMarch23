package com.mdasports.sportseventsweb.models.services;

public enum State { ENABLED, CANCELLED, FINISHED }
