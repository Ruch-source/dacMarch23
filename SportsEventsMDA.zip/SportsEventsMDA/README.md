# Sports events web

This project consists of to create an admin dashboard using Angular in Frontend and Java Spring Boot in Backend

## Build with 🛠️

* [Angular](https://angular.io) - A platform for building mobile and desktop web applications.
* [IntelliJ IDEA](https://www.jetbrains.com/idea) - An integrated development environment (IDE) written in Java for developing computer software.
* [Sourcetree](https://www.sourcetreeapp.com) - Simplicity and power in a beautiful Git GUI.
* [Spring Boot](https://spring.io) - An open source Java-based framework.
* [Villanuevand](https://github.com/Villanuevand) - **Andrés Villanueva** - README template.
* [Visual Studio Code](https://code.visualstudio.com/) - A source code editor that can be used with a variety of programming languages.

## Authors ✒️

* **Alejandro Perdomo González** - *-* - [Apergot](https://github.com/Apergot)
* **Diego Gustavo Hawkins Vargas** - *-* - [DiegoHawkins](https://github.com/DiegoHawkins)
* **Juan Kevin Trujillo Rodríguez** - *-* - [juankevinTR](https://juankevintrujillo.com)
* **Miguel Ángel Berciano Rodríguez** - *-* - [MiguelBerciano](https://github.com/MiguelBerciano)

## License 📄

This project has NO LICENSE, so, the work is under exclusive copyright by default.