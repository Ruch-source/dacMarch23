import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-enrollments',
  templateUrl: './admin-enrollments.component.html'
})
export class AdminEnrollmentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
