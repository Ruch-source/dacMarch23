export enum State {
  Enabled = 'ENABLED',
  Disabled = 'DISABLED',
  Finished = 'FINISHED'
}
