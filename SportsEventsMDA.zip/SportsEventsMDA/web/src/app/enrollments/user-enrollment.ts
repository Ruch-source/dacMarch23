export class UserEnrollment {
  rivalryName: string;
  rivalryDate: string;
  enrollmentDate: string;

  // tslint:disable-next-line:variable-name
  user_id: number;

  // tslint:disable-next-line:variable-name
  rivalry_id: number;

  // tslint:disable-next-line:variable-name
  enrollment_id: number;
}
