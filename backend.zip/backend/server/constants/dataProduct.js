const products = [
    {
        id : 1,
        name: "Shirts",
        filename: "shirt.png",
        description: "Any color, print type and material",
        price: 20
    },
    {
        id : 2,
        name: "T-Shirts",
        filename: "t-shirt.png",
        description: "Any color, print type and material",
        price: 15
    },
    {
        id : 3,
        name: "Trousers",
        filename: "trouser.png",
        description: "Any color, print type and material",
        price: 50
    },
    {
        id : 4,
        name: "Jeans",
        filename: "jeans.png",
        description: "Any color, print type and material",
        price: 80
    },
    {
        id : 5,
        name: "Boxers",
        filename: "boxer.png",
        description: "Any color, print type and material",
        price: 10
    },
    {
        id : 6,
        name: "Joggers",
        filename: "jogger.png",
        description: "Any color, print type and material",
        price: 90
    },{
        id : 7,
        name: "Others",
        filename: "other.png",
        description: "Any color, print type and material",
        price: 100
    }
]

module.exports = products;